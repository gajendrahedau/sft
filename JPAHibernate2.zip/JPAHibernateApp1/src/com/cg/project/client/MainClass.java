package com.cg.project.client;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;

public class MainClass {
	public static void main(String args[]){
		AssociateDAO associateDAO=new AssociateDAOImpl();
		
		Associate associate1=new Associate(1500, "Gaj", "Anand", "B", "Sr. Con.", "ASDFG675R", "gaj@gmail.com", new BankDetails(), new Salary());
		Associate associate2=new Associate(1300, "AMAN", "Anand", "B", "Sr. Con.", "ASDFG675R", "gaj@gmail.com", new BankDetails(), new Salary());

		
		//Associate associate=new Associate("Gajendra", "Hedau", "A", "gaj@gmail.com");
		
		associate1=associateDAO.save(associate1);
		associate2=associateDAO.save(associate2);
		System.out.println(associate1);
		System.out.println(associate2);
		
		System.out.println(associateDAO.findAll());
		//System.out.println(associate);
		
		//System.out.println(associateDAO.findOne(1));
		
		/*ArrayList<Associate>list=associateDAO.findAll();
		
		for (Associate associate2 : list) {
			System.out.println(associate2);
		}*/
		
		
		
		/*	Associate associate1=new Associate("Ashutosh", "Hedau", "gaj@gmail.com", "SR. CON");
		associate1=associateDAO.save(associate1);
		Associate associate2=new Associate("Anureet", "Hedau", "gaj@gmail.com", "SR. CON");
		associate2=associateDAO.save(associate2);
		Associate associate3=new Associate("Atul", "Hedau", "gaj@gmail.com", "SR. CON");
		associate3=associateDAO.save(associate3);
		
		System.out.println("Find one \n"+associateDAO.findOne(2));
		
		System.out.println("\n");
		
		System.out.println("Update \n");
		//associateDAO.update(associate3);
		//System.out.println(associate3);
		
		ArrayList<Associate>list=associateDAO.findAll();
		System.out.println("Find All\n");
		for (Associate associate : list) {
			System.out.println(associate);
		}
		
		
		
		//associate=associateDAO.save(associate);
		//System.out.println(associate1);
		//System.out.println(associate1);
		//System.out.println(associate1);
		//associate=associateDAO.findOne(1);
		//System.out.println("Associate ID= "+associate.getAssociateId());
*/		
		
		
		
	}
}
