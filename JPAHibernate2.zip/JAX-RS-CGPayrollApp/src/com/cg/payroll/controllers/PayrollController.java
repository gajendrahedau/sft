package com.cg.payroll.controllers;
public class PayrollController {
	public String get(){
		return "Hello World";
	}
}
