package com.cg.project.beans;

import javax.persistence.Entity;

@Entity
public class PEmployee extends Employee{
	private int dra,ta,da;
	
	public PEmployee() {}

	public PEmployee(int dra, int ta, int da) {
		super();
		this.dra = dra;
		this.ta = ta;
		this.da = da;
	}

	@Override
	public String toString() {
		return "PEmployee [dra=" + dra + ", ta=" + ta + ", da=" + da + "]";
	}

	public int getDra() {
		return dra;
	}

	public void setDra(int dra) {
		this.dra = dra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
	
	
}
