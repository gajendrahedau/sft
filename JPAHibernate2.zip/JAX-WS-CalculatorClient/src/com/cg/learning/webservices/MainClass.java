package com.cg.learning.webservices;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class MainClass {
	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:6754/cs?wsdl");
		
		
		QName qname=new QName("http://webservices.learning.cg.com/","CalculatorService");
		Service service=Service.create(url,qname);
		
		CalculatorServer endPointIntf=service.getPort(CalculatorServer.class);
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter 1st number for calculator operations");
		int num1=scanner.nextInt();
		System.out.println("Enter 2nt number for calculator operations");
		int num2=scanner.nextInt();
		System.out.println("Addition\t"+endPointIntf.addition(num1, num2));
		System.out.println("Subtraction\t"+endPointIntf.subtraction(num1, num2));
	}

}
