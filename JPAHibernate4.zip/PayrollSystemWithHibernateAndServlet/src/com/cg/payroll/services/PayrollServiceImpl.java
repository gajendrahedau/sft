package com.cg.payroll.services;
import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;

@WebServlet("/accepNewAssociate")
public class PayrollServiceImpl extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public PayrollServiceImpl() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		AssociateDAO associateDAO=new AssociateDAOImpl();
		
		//Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode),new Salary(basicSalary, epf, companyPf));
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		long accountNumber=Long.parseLong(request.getParameter("accountNumber"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPf=Integer.parseInt(request.getParameter("companyPf"));
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		String emailId=request.getParameter("emailId");
		String bankName=request.getParameter("bankName");
		String ifscCode=request.getParameter("ifscCode");
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
		associate=associateDAO.save(associate);
		request.setAttribute("associate", associate);
		request.setAttribute("string", "Congratulations.Your Registration has been Successfully done.Your Associate Id is ");
		RequestDispatcher dispatcher=request.getRequestDispatcher("acceptNewAssociatePage.jsp");
		dispatcher.forward(request, response);
	}

}
