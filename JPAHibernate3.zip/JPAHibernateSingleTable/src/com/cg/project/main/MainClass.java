package com.cg.project.main;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {
	
	public static void main(String[] args) {
		/*EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		factory.createEntityManager();*/
		System.out.println(MainClass.x);
		
		System.out.println((String)null);
		
    }
    static {
        System.out.println(MainClass.x);
    }
    static int x=90;
}
