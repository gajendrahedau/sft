package com.cg.project.beans;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int employeeId,baiscSalary;
	private String firstName,lastName;
	
	@Autowired
	private Address address;
	
	public Employee(int employeeId, int baiscSalary, String firstName, String lastName) {
		super();
		this.employeeId = employeeId;
		this.baiscSalary = baiscSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public int getBaiscSalary() {
		return baiscSalary;
	}
	public void setBaiscSalary(int baiscSalary) {
		this.baiscSalary = baiscSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", baiscSalary=" + baiscSalary + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", address=" + address + "]";
	}
	

}
