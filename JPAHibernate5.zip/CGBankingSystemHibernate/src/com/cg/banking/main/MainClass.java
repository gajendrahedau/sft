package com.cg.banking.main;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManagerFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		// EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();
		
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bservices=(BankingServices)context.getBean("bankingServices");
		
		try {
			long accountNo1=bservices.openAccount("Salary", 1000);
			System.out.println("Your Account Number : "+accountNo1);
			
			long accountNo2=bservices.openAccount("Saving", 2000);
			System.out.println("Your Account Number : "+accountNo2);
			
			long accountNo3=bservices.openAccount("Salary", 3000);
			System.out.println("Your Account Number : "+accountNo3);
			
			long accountNo4=bservices.openAccount("Saving", 4000);
			System.out.println("Your Account Number : "+accountNo4);
			
			System.out.println("Account Details of 2 \n"+bservices.getAccountDetails(accountNo2));
			
			System.out.println("Deposited Amount in Account 1 :\n "+bservices.depositAmount(1, 1000));
			
			System.out.println(bservices.getAccountDetails(accountNo1));
			System.out.println("Account Details of 1 after deposite \n"+bservices.getAccountDetails(accountNo1));
			
			System.out.println("Withdraw Amount from Account 2 :"+bservices.withdrawAmount(2, 200, 0000));
			
			System.out.println("Account Details of 2 after Withdraw \n"+bservices.getAccountDetails(accountNo2));
			
			List<Account>list=bservices.getAllAccountDetails();
			
			for (Account account : list) {
				System.out.println(account);
			}
			
			List<Transaction>transactionList=bservices.getAccountAllTransaction(2);
			for (Transaction transaction : transactionList) {
				System.out.println(transaction);
			}
			
		} catch (InvalidAmountException | InvalidAccountTypeException
				| BankingServicesDownException e) {
			e.printStackTrace();
		} catch (AccountNotFoundException e) {
			e.printStackTrace();
		} catch (AccountBlockedException e) {
			e.printStackTrace();
		} catch (InsufficientAmountException e) {
			e.printStackTrace();
		} catch (InvalidPinNumberException e) {
			e.printStackTrace();
		}
	}
}
