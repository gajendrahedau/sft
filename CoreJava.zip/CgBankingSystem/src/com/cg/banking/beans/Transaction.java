package com.cg.banking.beans;

public class Transaction {
	private int transactionId ,amount ;
	private String timeStamp ,transactionType ,transactionLocation ,modeoffTransaction ,transactionStatus ;

}
