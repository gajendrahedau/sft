package com.cg.banking.client;

import com.cg.banking.beans.Customer;

public class MainClass {

	public static void main(String[] args) {	
		
	}
}
