package com.cg.project.client;

public abstract class Vehicle {
	private int tyres;
	public void setTyres(int tyres){
		this.tyres=tyres;
	}
	public int getTyres(){
		return tyres;
	}
}

