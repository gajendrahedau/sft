package com.cg.project.client;

public class Car extends Vehicle{
	public int getTyres(int tyres){
		return super.getTyres()+1;
	}
}
