package com.cg.project.clients;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import com.cg.project.beans.Associate;
import com.cg.project.collectiondemo.AssociateComparator;
import com.cg.project.collectiondemo.HashMapDemo;
import com.cg.project.collectiondemo.ListClassesDemo;
import com.cg.project.collectiondemo.SetClassDemo;

public class MainClass {

	public static void main(String[] args) {
		
		HashMap<String, String>s=HashMapDemo.hashmap();
		
		System.out.println("AFTER THIS");
		System.out.println(s);
		
		/*ArrayList<Associate> arrList=new ArrayList<>();
		arrList.add(new Associate(101, 400000, "Gajendra"));
		arrList.add(new Associate(102, 50000, "Atul"));
		arrList.add(new Associate(102, 9000, "Aprajita"));
		arrList.add(new Associate(103, 50000, "Atul"));
		arrList.add(new Associate(109, 89600, "Hitesh"));
		arrList.add(new Associate(67, 500, "Malya"));
		for (Associate associate : arrList)
			System.out.println(associate);
		
		System.out.println("\n");
		
		Collections.sort(arrList);
		
		for (Associate associate : arrList)
			System.out.println(associate);
		
		Collections.sort(arrList,new AssociateComparator());
		
		System.out.println("\n");
		
		for (Associate associate : arrList)
			System.out.println(associate);
		
		ListClassesDemo.arrayListClassWork();*/
	}

}
