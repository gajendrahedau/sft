package com.cg.inheritance.beans;

public class PEmployee extends Employee{
	private int hra,ta,da;
	
	
	
	@Override
	public String toString() {
		return super.toString()+" hra=" + hra + ", ta=" + ta + ", da=" + da + "]";
	}

	public PEmployee() {}

	public PEmployee(int employeeId, String firsName, String lastName,
			int basicSalary) {
		super(employeeId, firsName, lastName, basicSalary);
	}

	@Override
	public void calculateTotalSalary() {
		hra=(this.getBasicSalary()*10)/100;
		da=(this.getBasicSalary()*10)/100;
		ta=(this.getBasicSalary()*10)/100;
		this.setTotalSalary(this.getBasicSalary()+hra+da+ta);
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
	
	
	
	
}
