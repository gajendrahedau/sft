public class EvenNumberInARange {
	public static void main(String[] args) {
		int x,y;
		x=20;y=40;
	    System.out.println("Even Numbers are:");
	    for(int i=x;i<=y;i++){
	    	
	    	if(i%2==0)
	    		System.out.println(i+"\n");
	    	}
	    }
}
