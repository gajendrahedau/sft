public class ThirdLargestInArray {
	public static void main(String[] args) {
		int numbers[]={1,2,3,24,74,78,12,90,34,66,59,22};
		int i=1,max=numbers[0],maxIndex=0,secondMaxIndex=0,secondMax=Integer.MIN_VALUE,thirdMax=Integer.MIN_VALUE;
		while(i<numbers.length){
			if(max<numbers[i]){
				max=numbers[i];
				maxIndex=i;
			}
			i++;
		}
		i=0;
		while(i<numbers.length){
			if(i==maxIndex){
				i++;continue;
			}
			
			else if(secondMax<numbers[i]){
				secondMax=numbers[i];
				secondMaxIndex=i;
			}
			i++;
		}
		i=0;
		while(i<numbers.length){
			if(i==maxIndex  || i==secondMaxIndex){
				i++;continue;
			}
			else if(thirdMax<numbers[i]){
				thirdMax=numbers[i];
			}
			i++;
		}
		System.out.println(thirdMax);
	}
}
