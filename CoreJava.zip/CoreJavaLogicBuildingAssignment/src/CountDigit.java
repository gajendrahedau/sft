
public class CountDigit {
	public static void main(String[] args) {
		int numbers[]={34,654,4,7,3,12,433,234,544,76,45};
		int i=0,one_digit=0,two_digit=0,three_digit=0;
		while(i<numbers.length){
			int n=numbers[i];
			if(n>=0 && n<=9)
				one_digit++;
			else if(n>9 && n<=99)
				two_digit++;
			else if(n>99 && n<=999)
				three_digit++;
			i++;
		}
		System.out.println("Count of One Digit : "+one_digit);
		System.out.println("Count of Two Digit : "+two_digit);
		System.out.println("Count of Three Digit : "+three_digit);
	}
}
