public class Factorial {
	public static void main(String[] args) {
		int num=5,fact=1,i;
		for(i=num;i>=1;i--){
			fact=fact*i;
		}
		System.out.println("Factorial of 5 is "+fact);
	}
}