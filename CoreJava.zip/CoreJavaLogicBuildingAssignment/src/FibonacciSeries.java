public class FibonacciSeries {
	public static void main(String[] args) {
		int a=0,b=1,c;
		int n=8,i;
		System.out.println("The Fibonacci series is as follows");
		System.out.println(a+"\n"+b);
		for(i=0;i<(n-2);i++){
				c=a+b;
				System.out.println(c);
				a=b;
				b=c;
		}
	}
}