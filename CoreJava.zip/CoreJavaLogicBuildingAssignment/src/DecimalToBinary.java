public class DecimalToBinary {
	public static void main(String[] args) {
        int n=16,a;
        String x = "";
        while(n > 0){
            a = n % 2;
            x = x + "" + a;
            n = n / 2;
        }
        StringBuilder input=new StringBuilder(x);
        input=input.reverse();
        System.out.println("Binary number:"+input);
    }
}
