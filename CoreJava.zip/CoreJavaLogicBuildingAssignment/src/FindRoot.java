class FindRoot{
	public  static void main(String args[]){
		int a=10,b=12,c=4;
		if(a==0)
			System.out.println("Root is : "+((-c)/a));
		else{
			int d=(b*b)-(4*a*c);
			if(d<0)
				System.out.println("Roots are imaginary");
			else{
				double root1=(-b+(Math.sqrt(d)))/(2*a);
				double root2=(-b-(Math.sqrt(d)))/(2*a);
				System.out.println("Root1 : "+root1 +" Root2 : "+root2);
			}
		}
	}
}