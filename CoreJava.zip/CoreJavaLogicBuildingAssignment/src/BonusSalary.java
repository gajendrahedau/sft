class BonusSalary{
	public static void main(String args[]){
		String designation="Senior COnsultant";
		int experience=7,basicSalary=20000,bonusSalary=0;
		if(experience>=5 && designation=="COnsultant")
			bonusSalary=(basicSalary*10)/100;
		else  if(experience>=5 && designation=="Senior COnsultant")
			bonusSalary=(basicSalary*20)/100;
		else  if(experience>=5 && designation=="Senior Analyst")
			bonusSalary=(basicSalary*20)/100;
		else  if(experience>=10 && designation=="Analyst")
			bonusSalary=(basicSalary*20)/100;
		else
			bonusSalary=(basicSalary*5)/100;
		System.out.println("Bonus Salary "+bonusSalary);
	}
}