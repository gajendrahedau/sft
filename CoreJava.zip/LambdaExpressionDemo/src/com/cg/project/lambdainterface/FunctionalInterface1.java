package com.cg.project.lambdainterface;
@FunctionalInterface
public interface FunctionalInterface1 {
	public void greetUser(String fName,String lName);
}
