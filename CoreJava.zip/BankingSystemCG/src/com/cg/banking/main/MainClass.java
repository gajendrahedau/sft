package com.cg.banking.main;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		BankingServices bservices=new BankingServicesImpl();
		try {
			 
			Account l1=bservices.getAccountDetails(10112);
			System.out.println(l1);
			
			float amount=bservices.depositAmount(10116,7600);
			 System.out.println("Total Amount  "+amount);
			
			 
			Account ac1=bservices.getAccountDetails(10112);
				System.out.println(ac1);
			
			bservices.openAccount("Saving", 1000);
			
			List<Account> l2=bservices.getAllAccountDetails();
			System.out.println(l2);
			
			Account ac=bservices.getAccountDetails(10116);
			System.out.println(ac);
			
		
			 
			bservices.fundTransfer(10104, 10110, 450000,1055);
			System.out.println("Fund Transfer Complete");
			
			
			
			 float amount1=bservices.depositAmount(10098,2000);
			 System.out.println("Total Amount  "+amount1);
			 
			 List<Transaction> l=bservices.getAccountAllTransaction(10098);
			 for (Transaction transaction : l) {
				System.out.println(transaction);
			}
			 
			System.out.println("Status ->"+bservices.accountStatus(546));

			System.out.println("Completed");
		} catch (BankingServicesDownException e) {
			System.out.println(e.getMessage());
		} catch (InvalidAmountException e) {
			System.out.println(e.getMessage());
		} catch (InvalidAccountTypeException e) {
			System.out.println(e.getMessage());
		} catch (InsufficientAmountException e) {
			System.out.println(e.getMessage());
		} catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (InvalidPinNumberException e) {
			System.out.println(e.getMessage());
		}catch (AccountBlockedException e) {
			System.out.println(e.getMessage());
		} 
	}
}
