package com.cg.enumdemo;
public class MainClass {
	public static void main(String[] args) {
		Month month=Month.FEB;
		Month month2=Month.MARCH;
		System.out.println("monthIndex : "+month.getMonthIndex());
		System.out.println("monthName : "+month.getMonthName());
		
		WeekDay weekday=WeekDay.SUN;
		System.out.println("Day :"+weekday.getDay());
	}
}
