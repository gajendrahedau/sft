package com.cg.project.beans;
public class Associate {
	private int associateId,age;
	private String firstName,lastName,designation,department,qualification,address,gender,dob;
	private String password;
	private String hobbies[]=new String[10];
	
	
	public Associate(int associateId, int age, String firstName,
			String lastName, String designation, String department,
			String qualification, String address, String gender, String dob,
			String password, String[] hobbies) {
		super();
		this.associateId = associateId;
		this.age = age;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.department = department;
		this.qualification = qualification;
		this.address = address;
		this.gender = gender;
		this.dob = dob;
		this.password = password;
		this.hobbies = hobbies;
	}

	public String[] getHobbies() {
		return hobbies;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}

	public Associate(int associateId, int age, String firstName,
			String lastName, String designation, String department,
			String qualification, String address, String gender, String dob,
			String password) {
		super();
		this.associateId = associateId;
		this.age = age;
		this.firstName = firstName;
		this.lastName = lastName;
		this.designation = designation;
		this.department = department;
		this.qualification = qualification;
		this.address = address;
		this.gender = gender;
		this.dob = dob;
		this.password = password;
	}

	public Associate() {}
	
	public Associate(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", age=" + age
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", designation=" + designation + ", department=" + department
				+ ", qualification=" + qualification + ", address=" + address
				+ ", gender=" + gender + ", dob=" + dob + ", password="
				+ password + "]";
	}

	public int getAssociateId() {
		return associateId;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + age;
		result = prime * result + associateId;
		result = prime * result
				+ ((department == null) ? 0 : department.hashCode());
		result = prime * result
				+ ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result
				+ ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result
				+ ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result
				+ ((qualification == null) ? 0 : qualification.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (age != other.age)
			return false;
		if (associateId != other.associateId)
			return false;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (qualification == null) {
			if (other.qualification != null)
				return false;
		} else if (!qualification.equals(other.qualification))
			return false;
		return true;
	}

}
