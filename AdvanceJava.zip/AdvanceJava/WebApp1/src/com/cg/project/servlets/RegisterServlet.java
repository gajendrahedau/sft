package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;
@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisterServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException {
		int associateId=Integer.parseInt(req.getParameter("associateId"));
		String password=req.getParameter("password");
		String firstName=req.getParameter("firstName");
		String lastName=req.getParameter("lastName");
		String department=req.getParameter("department");
		String designation=req.getParameter("designation");
		String dob=req.getParameter("dob");
		Date formatDate=null;
		try {
			 formatDate=new SimpleDateFormat("yyyy-mm-dd").parse(dob);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String hobbies[]=req.getParameterValues("hobbies");
		String gender=req.getParameter("gender");
		String email=req.getParameter("email");
		int age=Integer.parseInt(req.getParameter("age"));
		String qualification=req.getParameter("qualification");
		String address=req.getParameter("address");
		String resume=req.getParameter("resume");
		
		Associate associate=new Associate(associateId, age, firstName, lastName, designation, department, qualification, address, gender, dob, password, hobbies);
		
		RequestDispatcher dispatcher;
		
		dispatcher=req.getRequestDispatcher("registrationSuccessPage.jsp");
		req.setAttribute("associate", associate);
		dispatcher.forward(req, resp);
		
		
		/*PrintWriter out=resp.getWriter();
		out.print("<html><body><div align='center'><table border=3>");
		out.print("<tr><td>AssociateId</td><td>"+associateId+"</td></tr>");
		out.print("<tr><td>password</td><td>"+password+"</td></tr>");
		out.print("<tr><td>firstName</td><td>"+firstName+"</td></tr>");
		out.print("<tr><td>lastName</td><td>"+lastName+"</td></tr>");
		out.print("<tr><td>department</td><td>"+department+"</td></tr>");
		out.print("<tr><td>designation</td><td>"+designation+"</td></tr>");
		out.print("<tr><td>gender</td><td>"+gender+"</td></tr>");
		out.print("<tr><td>email</td><td>"+email+"</td></tr>");
		out.print("<tr><td>age</td><td>"+age+"</td></tr>");
		out.print("<tr><td>qualification</td><td>"+qualification+"</td></tr>");
		out.print("<tr><td>address</td><td>"+address+"</td></tr>");
		out.print("<tr><td>resume</td><td>"+resume+"</td></tr>");
		out.print("<tr><td>dob</td><td>"+dob+"</td></tr>");
		out.print("<tr><td>formatDate</td><td>"+formatDate+"</td></tr>");
		out.print("<tr><td>Hobbies</td><td>");
		for (String hobby : hobbies) 
			out.print(hobby+"\t");
		out.print("</td></tr>");
		out.print("<table></div></body></html>");
	}*/
	/*public void init(ServletConfig config) throws ServletException {
	}
	public void destroy() {
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.print("<html><head><title>SigIn</title><script>function fun(){document.getElementById(target).innerHTML=Form has successfully submitted;	return false;}</script></head><h1 align=center style=color:green>Employees Details<br>This is servlet class for Registering</h1><body style=background-color:gray><form onsubmit=return fun()><table ><tr><td>Enter Associate ID</td><td><input type=number required></td></tr>");
		out.print("<tr><td>Enter First Name</td><td><input type=text  required></td></tr><tr><td>Enter Last Name</td><td><input type=text required></td></tr><tr><td>Enter Department</td><td><input type=text pattern=[A-Za-z\\s]+ required></td></tr><tr><td>Enter Designation</td><td><input type=text required></td</tr><tr><td>Enter DOB</td><td><input type=date required></td></tr><tr><td>Enter User Name</td><td><input type=text required name=userName id=userName></td></tr>");
		out.print("<tr><td>Enter password</td><td><input type=password required id=password name=password></td></tr><tr><td>Hobbies</td><td><input type=checkbox name=HB>Cricket</td><td><input type=checkbox name=HB>BasketBall</td><td><input type=checkbox name=HB>Hockey</td><td><input type=checkbox name=HB>Others</td></tr><tr><td>Gender</td><td><input type=radio name=G>Male</td><td><input type=radio name=G>Female</td></tr><tr><td>Qualification</td><td><select><option>Graduation</option><option>Post Graduation</option></select></td></tr>");
		out.print("<tr><td>Enter EmailID</td><td><input type=email required></td></tr><tr><td>Enter Age</td><td><input type=number maxlength=10 required></td></tr><tr><td>Enter Address</td><td><textarea cols=30 rows=5 required></textarea></td></tr><tr><td>Resume</td><td><input type=file required></td></tr><tr><td><input type=submit value=Save name=submit ></td><td><input type=reset value=Reset name=submit></td></tr></table></form><div id=target align=center style=color:red><strong></strong></div></body></html>");
		*/
	}
}



